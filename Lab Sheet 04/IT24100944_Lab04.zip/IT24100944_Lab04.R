setwd("C:\\Users\\it24100944\\Desktop\\IT24100944")
getwd()
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
str(branch_data)
summary(branch_data)
boxplot(branch_data$Sales_X1,
        main="Boxplot of Sales",
        ylab="Sales",
        col="green")
summary(branch_data$Advertising_X2)
QR_advertising<-IQR(branch_data$Advertising_X2)
QR_advertising
find_outliers<-function(x){
  Q1<-quantile(x,0.25)
  Q3<-quantile(x,0.75)
  QR_value<-QR(x)
  lower_bound<-Q1-1.5*QR_value
  upper_bound<-Q3+1.5*QR_value
  
  outliers<-x[x<lower_bound|x>upper_bound]
  return(outliers)
}
